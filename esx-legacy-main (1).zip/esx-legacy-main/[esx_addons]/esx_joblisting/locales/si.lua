Locales['si'] = {
  ['new_job'] = 'imaš novo službo!',
  ['access_job_center'] = 'pritisnite ~INPUT_PICKUP~ za dostop do ~b~job center~s~.',
  ['job_center'] = 'center za delovna mesta',
}
