Locales['hu'] = {
	['veh_released'] = 'A jármü sikersen kivéve',
	['veh_stored'] = 'A jármü sikersen eltárolva',
	['veh_health'] = 'Tárolás elött meg kell javitanod a jármüvet',
}
