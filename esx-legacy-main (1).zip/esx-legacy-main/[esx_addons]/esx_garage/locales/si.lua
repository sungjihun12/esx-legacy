Locales['si'] = {
	['veh_released'] = 'vozilo je bilo ~g~spuščeno',
	['veh_stored'] = 'vozilo je bilo ~g~pospravljeno',
	['veh_health'] = 'vozilo boš moral popraviti, preden ga boš shranil.',
}
