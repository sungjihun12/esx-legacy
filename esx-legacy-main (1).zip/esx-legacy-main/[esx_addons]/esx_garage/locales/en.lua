Locales['en'] = {
	['veh_released'] = 'the vehicle has been ~g~released',
	['veh_stored'] = 'the vehicle has been ~g~stored',
	['veh_health'] = 'you\'ll have to repair the vehicle before storing it.',
}
