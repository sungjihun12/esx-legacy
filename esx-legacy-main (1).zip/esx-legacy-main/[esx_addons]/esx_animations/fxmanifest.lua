fx_version 'adamant'

game 'gta5'

description 'ESX Animations'

version '1.7.0'

client_scripts {
	'@es_extended/imports.lua',
	'config.lua',
	'client/main.lua'
}

dependency 'es_extended'
