USE `es_extended`;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('dmv', 'Permis de conduire'),
	('drive', 'Licence de conduite'),
	('drive_bike', 'Permis de motocyclette'),
	('drive_truck', 'Licence de conduite commerciale')
;
