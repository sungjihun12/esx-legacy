Locales['si'] = {
  ['used_bread'] = 'uporabili ste ~y~1x~s~ ~b~bread~s~',
  ['used_water'] = 'uporabili ste ~y~1x~s~ ~b~water~s~',
}