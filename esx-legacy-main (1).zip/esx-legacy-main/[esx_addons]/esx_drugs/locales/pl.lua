Locales ['pl'] = {
  -- weed (marihuana)
  ['weed_pickupprompt'] = 'naciśnij ~INPUT_CONTEXT~ aby zebrać liście ~g~Konopii~s~.',
  ['weed_quitprocess'] = 'naciśnij ~INPUT_CONTEXT~ aby przestać ~g~Przerabianie Marihuany~s~.',
  ['weed_inventoryfull'] = '~r~Nie możesz~s~ zebrać więcej konopii, nie masz wystarczająco miejsca w ekwipunku!',
  ['weed_processprompt'] = 'naciśnij ~INPUT_CONTEXT~ aby rozpocząć ~g~Przerabianie Marihuany~s~.',
  ['weed_processingstarted'] = 'przerabianie ~g~Konopii~s~ na ~g~Marihuane~s~...',
  ['weed_processingfull'] = 'przerabianie ~r~przerwane~s~ ponieważ masz pełny ekwipunek!',
  ['weed_processingenough'] = 'potrzebujesz ~b~3x~s~ ~g~Konopii~s~ aby rozpocząć przerabianie.',
  ['weed_processed'] = 'przerobiłeś ~b~3x~s~ ~g~Konopii~s~ na ~b~1x~s~ ~g~Marihuane~s~',
  ['weed_processingtoofar'] = 'przerabianie zostało ~r~przerwane~s~ ponieważ opuściłeś teren.',

  -- drug dealer (dealer narkotyków)
  ['dealer_prompt'] = 'naciśnij ~INPUT_CONTEXT~ aby rozmawiać z ~r~Dealerem Narkotyków~s~.',
  ['dealer_title'] = 'dealer Narkotyków',
  ['dealer_item'] = '$%s',
  ['dealer_notenough'] = 'nie masz tego wystarczająco aby to sprzedać!',
  ['dealer_sold'] = 'sprzedałeś ~b~%sx~s~ ~y~%s~s~ za ~g~$%s~s~',

  -- license (licencje)
  ['license_title'] = 'musisz posiadać licencję na przetwarzanie aby przerobić ten produkt, możesz zakupić ją tutaj.',
  ['license_no'] = 'nie',
  ['license_bought'] = 'kupiłeś ~b~%s~s~ za ~r~$%s~s~',
  ['license_bought_fail'] = 'nie stać cię na ~b~%s~s~!',
  ['license_weed'] = 'licencja na przetwarzanie zioła',

  -- blips (znaczniki)
  ['blip_weedfield'] = 'plantacja Marihuany',
  ['blip_weedprocessing'] = 'przeróbka Marihuany',
  ['blip_drugdealer'] = 'dealer Narkotyków',
}
