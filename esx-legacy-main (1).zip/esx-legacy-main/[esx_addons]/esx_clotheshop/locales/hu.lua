Locales["hu"] = {
	["valid_this_purchase"] = "Megerősíted a vásárlást?",
	["yes"] = "igen",
	["no"] = "nem",
	["not_enough_money"] = "Nincs elég pénzed",
	["press_menu"] = "Nyomd meg a ~INPUT_CONTEXT~ gombot a  ~y~Ruhabolt~s~ megnyitásához.",
	["clothes"] = "ruhabolt",
	["you_paid"] = "fizettél ~g~%s$-t~s~",
	["save_in_dressing"] = "Menteni szeretnéd a ruhát az ingatlanodban?",
	["name_outfit"] = "Ruha neve",
	["saved_outfit"] = "Ruha mentésre került!",
}
