Locales['en'] = {
  ['valid_this_purchase'] = 'potrdi ta nakup?',
  ['yes'] = 'da',
  ['no'] = 'no',
  ['not_enough_money'] = 'nimate dovolj denarja',
  ['press_menu'] = 'pritisnite ~INPUT_CONTEXT~ za dostop do ~y~Clothing Shop~s~.',
  ['clothes'] = 'trgovina z oblačili',
  ['you_paid'] = 'plačal si ~g~$%s~s~',
  ['save_in_dressing'] = 'ali želite oblačila shraniti v svojo lastnino?',
  ['name_outfit'] = 'poimenuj svojo obleko',
  ['saved_outfit'] = 'obleka je shranjena!',
}