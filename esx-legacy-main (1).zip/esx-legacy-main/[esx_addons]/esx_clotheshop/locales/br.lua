Locales['br'] = {
  ['valid_this_purchase'] = 'validar esta compra?',
  ['yes'] = 'sim',
  ['no'] = 'não',
  ['not_enough_money'] = 'você não tem dinheiro suficiente',
  ['press_menu'] = 'pressione ~INPUT_CONTEXT~ para acessar o menu',
  ['clothes'] = 'roupas',
  ['you_paid'] = 'você pagou ~g~$%s~s~',
  ['save_in_dressing'] = 'você quer salvar essa roupa?',
  ['name_outfit'] = 'nome da roupa?',
  ['saved_outfit'] = 'roupa salva',
}