Locales['en'] = {
  ['valid_purchase'] = 'validate this purchase?',
  ['yes'] = 'yes',
  ['no'] = 'no',
  ['not_enough_money'] = 'you do not have enough money',
  ['press_access'] = 'press ~INPUT_CONTEXT~ to access the ~y~Barber Shop~s~.',
  ['barber_blip'] = 'barber Shop',
  ['you_paid'] = 'you paid ~g~$%s~s~',
}
