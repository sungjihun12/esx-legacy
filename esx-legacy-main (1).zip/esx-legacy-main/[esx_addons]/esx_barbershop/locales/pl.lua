Locales['pl'] = {
  ['valid_purchase'] = 'potwierdzić ten zakup?',
  ['yes'] = 'tak',
  ['no'] = 'nie',
  ['not_enough_money'] = 'nie posiadasz wystarczająco pieniędzy',
  ['press_access'] = 'naciśnij ~INPUT_CONTEXT~ aby otworzyć ~y~Fryziera~s~.',
  ['barber_blip'] = 'fryzjer',
  ['you_paid'] = 'zapłaciłeś/aś ~g~$%s~s~',
}
