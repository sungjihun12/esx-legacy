Locales['en'] = {
  ['valid_purchase'] = 'potrdi ta nakup?',
  ['yes'] = 'da',
  ['no'] = 'no',
  ['not_enough_money'] = 'nimate dovolj denarja',
  ['press_access'] = 'pritisnite ~INPUT_CONTEXT~ za dostop do ~y~Barber Shop~s~.',
  ['barber_blip'] = 'Frizerski Salon',
  ['you_paid'] = 'plačali ste ~g~$%s~s~',
}
