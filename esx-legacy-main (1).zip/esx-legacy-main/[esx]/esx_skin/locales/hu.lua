Locales["hu"] = {
	["skin_menu"] = "Kinézet Menü",
	["use_rotate_view"] = "Használd ~INPUT_FRONTEND_LS~ vagy ~INPUT_CHARACTER_WHEEL~ gombokat a forgatáshoz",
	["skin"] = "kinézet változtatása",
	["saveskin"] = "kinézet mentése fájlba",
}
