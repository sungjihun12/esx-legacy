Locales['sv'] = {
  ['skin_menu'] = 'Skin meny',
  ['use_rotate_view'] = 'Använd ~INPUT_FRONTEND_LS~ och ~INPUT_CHARACTER_WHEEL~ för att rotera vyn.',
  ['skin'] = 'Ändra skin',
  ['saveskin'] = 'Spara skin till en fil',
}
