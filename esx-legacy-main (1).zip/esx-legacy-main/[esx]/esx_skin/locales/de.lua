Locales['de'] = {
  ['skin_menu'] = 'Skin Menü',
  ['use_rotate_view'] = 'Nutze ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ und ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ um dich umzuschauen.',
  ['skin'] = 'Skin ändern',
  ['saveskin'] = 'Skin in Datei speichern',
}
