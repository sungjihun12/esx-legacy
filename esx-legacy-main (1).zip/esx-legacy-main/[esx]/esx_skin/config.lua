Config = {}

Config.Locale = 'en'

Config.BackpackWeight = {
	[40] = 16, 
	[41] = 20, 
	[44] = 25, 
	[45] = 23
}
