Config = {}

Config.Fade = true