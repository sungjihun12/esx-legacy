## Use

 * ESX Function
```lua
    ESX.Progressbar("test", 25000,{FreezePlayer = false, animation ={type = "anim",dict = "mini@prostitutes@sexlow_veh", lib ="low_car_sex_to_prop_p2_player" }, onFinish = function()

```

* Export
```lua
    exports["esx_progressbar"]:Progressbar("test", 25000,{FreezePlayer = false, animation ={type = "anim",dict = "mini@prostitutes@sexlow_veh", lib ="low_car_sex_to_prop_p2_player" }, onFinish = function()
    ```
